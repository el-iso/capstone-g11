﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DanceDance_Manager : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	void FixedUpdate () {
		
	}
}
