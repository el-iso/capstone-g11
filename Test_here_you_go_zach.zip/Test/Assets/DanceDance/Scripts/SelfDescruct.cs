﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelfDescruct : MonoBehaviour {

    
    public float fuse = 0.0f;
    public float range = 0.0f;

    private float timeCreated;
    private Transform tr;
    private Vector3 originPos;

	// Use this for initialization
	void Start () {
        this.timeCreated = Time.time;
        this.tr = this.gameObject.transform;
        this.originPos = this.tr.position;
	}
	
	void FixedUpdate () {
        if ((fuse > 0.0f && Time.time - this.timeCreated > fuse) || (range > 0.0f && (this.tr.position - this.originPos).magnitude > range))
        {
            this.gameObject.SetActive(false);
            Destroy(this.gameObject);
        }
	}

    public void Destruct()
    {
        this.gameObject.SetActive(false);
        Destroy(this.gameObject);
    }
}
