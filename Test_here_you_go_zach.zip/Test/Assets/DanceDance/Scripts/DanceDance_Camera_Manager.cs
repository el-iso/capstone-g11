﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace UnityEngine.Rendering.PostProcessing
{
    public class DanceDance_Camera_Manager : MonoBehaviour
    {


        public float rotatePeriod;
        [Range(0, 360)]
        public float rotateRange;
        [Range(0, 360)]
        public float rotateSpeed;
        public float rotateZoomDepth;


        private float nextRotate;
        private float rotateCounter;
        private bool isRotating;
        private float startY;
        private bool pegChangedAlready = false;

        private Peg_Manager pegMan;
        private Bloom bloomSetting;
        private ChromaticAberration chomeSetting;
        private ColorGrading colorGradingSetting;

        // Use this for initialization
        void Start()
        {
            this.nextRotate = Time.time + this.rotatePeriod;
            this.rotateCounter = 0;
            this.isRotating = false;
            this.startY = this.transform.position.y;
        }

        // Update is called once per frame
        void FixedUpdate()
        {

            //If Peg_Man is not found yet, find it.
            if (pegMan == null)
            {
                this.pegMan = GameObject.Find("Peg_Manager").GetComponent<Peg_Manager>();
            }
            //If bloomSetting is not found yet, find it
            if (bloomSetting == null)
            {
                GameObject.Find("DanceDance Volume PostFX").GetComponent<PostProcessVolume>().profile.TryGetSettings<Bloom>(out this.bloomSetting);
            }
            //If chromSetting is not found yet, find it
            if (this.chomeSetting == null)
            {
                GameObject.Find("DanceDance Volume PostFX").GetComponent<PostProcessVolume>().profile.TryGetSettings<ChromaticAberration>(out this.chomeSetting);
            }
            //If colorGradingSetting is not found yet, find it
            if (this.colorGradingSetting == null)
            {
                GameObject.Find("DanceDance Volume PostFX").GetComponent<PostProcessVolume>().profile.TryGetSettings<ColorGrading>(out this.colorGradingSetting);
            }

            this.rotateSpeed = this.rotateSpeed < this.rotateRange ? this.rotateSpeed : this.rotateRange;

            if (!isRotating && Time.time > this.nextRotate)
            {
                this.nextRotate = Time.time + this.rotatePeriod;
                this.isRotating = true;
                this.pegChangedAlready = false;
            }

            if (this.isRotating)
            {
                float rotateAmount = this.rotateCounter + this.rotateSpeed <= this.rotateRange ? this.rotateSpeed : this.rotateRange - this.rotateCounter;
                this.transform.Rotate(new Vector3(0, 0, rotateAmount));
                this.rotateCounter += rotateAmount;


                if (this.rotateCounter >= this.rotateRange) //Should be finished rotating and no effects
                {
                    this.transform.position = new Vector3(this.transform.position.x, this.startY, this.transform.position.z);
                    this.isRotating = false;
                    this.rotateCounter = 0;
                    this.bloomSetting.intensity.Override(1);
                    this.colorGradingSetting.saturation.Override(0);
                }
                else //Some inbetween effects and rotation amounts
                {
                    //Calcuate the zoom amount
                    float percentRotateDone = (this.rotateCounter / this.rotateRange);
                    float sinWave = Mathf.Sin(percentRotateDone * Mathf.PI);

                    this.transform.position = new Vector3(this.transform.position.x, this.startY - (sinWave * this.rotateZoomDepth), this.transform.position.z); //Zoom the appropriate amount

                    if (!this.pegChangedAlready && percentRotateDone > 0.5f) //Change the peg in the middle of the rotation if its not already changed this rotation
                    {
                        Peg_Manager.SensorEnum newPegType = this.pegMan.Heart_Resp_OX_ECG == Peg_Manager.SensorEnum.H ? Peg_Manager.SensorEnum.R : Peg_Manager.SensorEnum.H;
                        this.pegMan.ChangePegs(newPegType);
                        this.pegChangedAlready = true;
                    }

                    this.bloomSetting.intensity.Override(1 + sinWave);
                    this.colorGradingSetting.colorFilter.Override(new UnityEngine.Color(1 - sinWave, 1 - sinWave, 1 - sinWave));
                }
            }
        }
    }
}




