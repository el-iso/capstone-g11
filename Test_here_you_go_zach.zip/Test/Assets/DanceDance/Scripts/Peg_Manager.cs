﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Peg_Manager : MonoBehaviour {

    public enum SensorEnum { H, R, OX, ECG };

    public GameObject heartPeg;
    public GameObject respPeg;
    public GameObject OXPeg;
    public GameObject ECGPeg;

    public float xSpeed;
    
    public SensorEnum Heart_Resp_OX_ECG;

    

    private float BeatsPerMinute = 0;
    private float nextSpawnTime;
    private GameObject currentPeg;
    private SensorEnum currentType;

    private List<GameObject> pegs = new List<GameObject>();

    // Use this for initialization
    void Start()
    {
        this.currentType = this.Heart_Resp_OX_ECG;
        this.currentPeg = this.getCurrentPeg();
    }
    
    void FixedUpdate()
    {
        if (this.Heart_Resp_OX_ECG != this.currentType)
        {
            this.currentPeg = this.getCurrentPeg();
            this.currentType = this.Heart_Resp_OX_ECG;
            //this.replacePegs();
            this.destroyPegs();
        }


        if (this.BeatsPerMinute < 1)
        {
            this.BeatsPerMinute = this.getBeatsPerMinute();
        }
        else if (Time.time > this.nextSpawnTime)
        {
            this.BeatsPerMinute = this.getBeatsPerMinute();
            float secondsPerBeat = (60.0f) / this.BeatsPerMinute;
            this.nextSpawnTime = Time.time + (secondsPerBeat);

            GameObject obj = Instantiate(this.currentPeg, transform.position, transform.rotation);
            foreach (Transform trans in obj.GetComponentsInChildren<Transform>(true))
            {
                trans.gameObject.layer = this.transform.gameObject.layer;
            }
            this.pegs.Add(obj);
        }


        foreach (GameObject obj in this.pegs)
        {
            if (obj != null && obj.activeInHierarchy)
            {
                obj.transform.Translate(new Vector3(xSpeed / 60.0f, 0.0f, 0.0f));
            }
        }
    }

    private float getBeatsPerMinute()
    {
        float val = 0;
        if (Heart_Resp_OX_ECG == SensorEnum.H)
        {
            val = MongoInterface.GetHeartbeat();
        }
        else if (Heart_Resp_OX_ECG == SensorEnum.R)
        {
            val = MongoInterface.GetRespiration();
        }
        else
        {
            val = MongoInterface.GetBloodOxygen();
        }
        return val;
    }

    private GameObject getCurrentPeg()
    {
        GameObject peg = this.heartPeg;

        if (Heart_Resp_OX_ECG == SensorEnum.H)
        {
            peg = this.heartPeg;
        }
        else if (Heart_Resp_OX_ECG == SensorEnum.R)
        {
            peg = this.respPeg;
        }
        else
        {
            peg = this.OXPeg;
        }
        return peg;
    }

    private void replacePegs()
    {
        List<GameObject> newPegs = new List<GameObject>();
        foreach(GameObject old in this.pegs)
        {
            if (old != null && old.activeInHierarchy && DistanceFrom(old, this.transform.position) < 10)
            {
                GameObject obj = Instantiate(this.currentPeg, old.transform.position, old.transform.rotation);
                foreach (Transform trans in obj.GetComponentsInChildren<Transform>(true))
                {
                    trans.gameObject.layer = this.transform.gameObject.layer;
                }
                newPegs.Add(obj);
            }

            if (old != null)
            {
                old.SetActive(false);
                Destroy(old);
            }
        }

        this.pegs = newPegs;
    }

    private void destroyPegs()
    {
        List<GameObject> newPegs = new List<GameObject>();
        foreach (GameObject old in this.pegs)
        {
            if (old != null)
            {
                old.SetActive(false);
                Destroy(old);
            }
        }

        this.pegs = newPegs;
    }

    public float DistanceFrom(GameObject obj, Vector3 origin)
    {
        float dist = 0;

        dist = (obj.transform.position - origin).magnitude;

        return dist;
    }

    public void ChangePegs(SensorEnum S)
    {
        this.Heart_Resp_OX_ECG = S;
    }
}
